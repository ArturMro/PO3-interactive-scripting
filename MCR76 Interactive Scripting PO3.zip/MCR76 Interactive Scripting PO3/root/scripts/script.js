
console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
  addMyEventListener()
  getDate()

});

function addMyEventListener(){

	/* Hamburger Menu */
	$('.hamburger').click(function(){
		console.log("Hamburger Clicked");
		$(this).toggleClass('opened');
		$('header nav').toggleClass('active');
		
	});

}


//update year in footer
function getDate(){
	var d = new Date();
	var n = d.getFullYear()
	console.log('got full year');
	$('.year').html(n);
}
