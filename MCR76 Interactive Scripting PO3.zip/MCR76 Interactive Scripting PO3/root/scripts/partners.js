document.write("<ul>");
document.write("<li>MakeFlow Inc.</li>");
document.write("<li>WinTel Inc.</li>");
document.write("<li>Plums and  Pears Ltd.</li>");
document.write("<li>Pay A Friend Inc.</li>");
document.write("</ul>");