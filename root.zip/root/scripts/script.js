
console.log('Script file loaded.');

$(document).ready(function(){

  console.log('HTML file loaded and parsed.');
  
  addMyEventListener()
  topSlider()
  typing()
  footerSlider()
  getDate() 
  
});



function addMyEventListener(){

	/* Hamburger Menu */
	$('.hamburger').click(function(){
		$(this).toggleClass('opened');
		$('header nav').toggleClass('active');
	});

	// Pricing
	$('#pricing').click(function(){
        checkDomain()
	});

}

/* top and bottom slider settings */

var speed = 500;            // fade speed
var autoLoopSpeed = 3000;   // auto slider speed



/* top slider */

function topSlider(){

    // Add inital active class to first image
    $('.slide').first().addClass('active');
    
    // Hide all slides
    $('.slide').hide();

    // show first slide image
    $('.active').show();


    // next button
    $('#next').click(nextSlide);

    // prev button
    $('#prev').click(prevSlide);

    // auto slider
    setInterval(nextSlide, autoLoopSpeed);

    // switch to next slide
    function nextSlide(){
        $('.active').removeClass('active').addClass('oldActive');
        if($('.oldActive').is(':last-child')){                    
            $('.slide').first().addClass('active');					// display first image after the last image 
        } else {
            $('.oldActive').next().addClass('active');				// or keep displaying the next image
        }
        $('.oldActive').removeClass('oldActive');
        $('.slide').fadeOut(speed);
        $('.active').fadeIn(speed);
    }

    // switch prev slide
    function prevSlide(){
        $('.active').removeClass('active').addClass('oldActive');
        if($('.oldActive').is(':first-child')){
            $('.slide').last().addClass('active');
        } else {
            $('.oldActive').prev().addClass('active');
        }
        $('.oldActive').removeClass('oldActive');
        $('.slide').fadeOut(speed);
        $('.active').fadeIn(speed);
    }
}


// footer slider

function footerSlider(){

	// Add inital active class
    $('.footerSlide').first().addClass('footerActive');
    
    // Hide all slides
    $('.footerSlide').hide();

    // show first slide image
	$('.footerActive').show();

	setInterval(function(){
		$('.footerActive').removeClass('footerActive').addClass('footerOldActive');
        if($('.footerOldActive').is(':last-child')){
            $('.footerSlide').first().addClass('footerActive');
        } else {
            $('.footerOldActive').next().addClass('footerActive');
        }
        $('.footerOldActive').removeClass('footerOldActive');
        $('.footerSlide').fadeOut(speed);
        $('.footerActive').fadeIn(speed);
	}, autoLoopSpeed);

}


//update year in footer
function getDate(){
	var d = new Date();          // get new date
	var n = d.getFullYear()		 // get year only from the new date
	$('.year').html(n);			 // display year in html year class
}


// text typing effect

function typing(){
	var text = "Let's build your site!";               // assign new content to variable
	function letter() {
		var animatedText = $('#animatedText').text(); 
		var t = text.charAt(0);                        // grab first text's letter
		text = text.substr(1);						   // shorten the text
		$('#animatedText').text(animatedText + t);	   // add first letter
		if(text.length > 0) setTimeout(letter, 75);	   // if there's anything left to type, continue.
	}
		setTimeout(letter, 75);
}
	

// Pricing script

function checkDomain() {
    domainName = $("#txt").val(); //Added parentesis in function val
    var name = domainName.split('.')  //Added var before name variable
    window.alert("You are looking for a "+"." + name[1] + " domain"); // Added space before domain word
    x = money('.' + name[1]); //name(1) changed to name[1]
    
    if (x === false) {
    $("#results").html("We don't have a price for this domain right now! Please call use later!"); //Changed "innerHTML =" to html()
    }
    else
    $("#results").html("Well done. Your domain will cost you " + x  + " Try again?");  //Changed "innerHTML =" to html()
}
function money(name) {
    m = [{tld:'.aero', price:'€78.00'}, {tld:'.asia', price:'€19.49'},{tld:'.biz', price:'€18.60'},{tld:'.co', price:'€€25.00'},{tld:'.co.com', price:'€33.00'},{tld:'.com', price:'€15.99'},{tld:'.coop', price:'€138.00'},{tld:'.info', price:'€19.99'},{tld:'.jobs', price:'€129.99'},{tld:'.mobi', price:'€18.00'},{tld:'.name', price:'€14.00'},{tld:'.net', price:'€19.99'},{tld:'.org', price:'€19.99'},{tld:'.pro', price:'€18.00'},{tld:'.tel', price:'€18.00'},{tld:'.travel', price:'€98.00'},{tld:'.ie', price:'€19.99'},{tld:'.uk.com', price:'€38.00'},{tld:'.lu', price:'€34.00'},{tld:'.co.uk', price:'€16.50'}]  //added square bracked to create array m
    for(var i = 0; i < m.length; i++) { //added loop to find mayching "tld"
        var obj = m[i];
        if (obj.tld == name) {return obj.price}
    }
    return false
}